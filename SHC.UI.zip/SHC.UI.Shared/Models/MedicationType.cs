﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SHC.UI.Shared.Models
{
    public enum MedicationType
    {
        Tablet,
        Injection,
        Liquid
    }
}
